from raytracing.geometry import CubicBezier

p = CubicBezier((1,1),(1,1),(1,1),(1,1))
print(p)