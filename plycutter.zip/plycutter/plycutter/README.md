# Plycutter - convert STL 3D models to finger-jointed 2D DXF laser cutter inputs

For more information, see the [documentation](https://tjltjl.github.io/plycutter)

<img align="right" src="docs/biocta-cut-1.jpg" alt="Laser cut output, assembled" width="30%"/>
<img align="right" src="docs/biocta-1.png" alt="CAD model" width="30%"/>
<img align="right" src="docs/biocta-pattern.png" alt="CAD model" width="71%"/>
