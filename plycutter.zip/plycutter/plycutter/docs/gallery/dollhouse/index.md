# Dollhouse

<img align="right" width="30%" src="painted-1.jpeg"/>

Author: Tuomas Lukka (tjltjl)

Material: 6mm plywood

Tools: Fusion 360

The project that launched plycutter. 

The original CAD model:

<img src="model.jpeg" alt="CAD model"/>

Laser-cut and glued:

<img src="view1.jpeg"/>
<img src="view2.jpeg"/>
<img src="view3.jpeg"/>

Painted and with wallpaper:

<img src="painted-1.jpeg"/>
<img src="painted-2.jpeg"/>
