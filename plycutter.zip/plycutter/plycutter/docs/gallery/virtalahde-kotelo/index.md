# Box for DPS5020 Digital Power Supply

<img align="right" width="30%" src="virtalahde-kotelo-etu.jpg"/>
<img align="right" width="30%" src="virtalahde-kotelo-taka.jpg"/>

Author: Jukka Järvenpää/Helsinki Hacklab

Material: 3mm acrylic

Tools: Fusion 360

The original CAD model:

<img src="virtalahde-kotelo-v98.jpg" alt="CAD model"/>

