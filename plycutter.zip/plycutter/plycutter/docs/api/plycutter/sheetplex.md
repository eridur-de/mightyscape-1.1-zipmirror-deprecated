# plycutter.sheetplex

---

# plycutter.sheetplex.SheetPlex

::: plycutter.sheetplex.SheetPlex

---

# plycutter.sheetplex.Sheet

::: plycutter.sheetplex.Sheet

---

# plycutter.sheetplex.Intersection

::: plycutter.sheetplex.Intersection

---

# plycutter.sheetplex.InterSide

::: plycutter.sheetplex.InterSide
