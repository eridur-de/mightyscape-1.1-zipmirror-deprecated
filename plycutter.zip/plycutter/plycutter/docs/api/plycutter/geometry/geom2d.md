# plycutter.geometry.geom2d

## plycutter.geometry.geom2d.Geom2D

::: plycutter.geometry.geom2d.Geom2D
    selection:
        inherited_members: yes

