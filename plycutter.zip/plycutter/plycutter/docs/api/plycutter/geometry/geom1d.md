# plycutter.geometry.geom1d

## plycutter.geometry.geom1d.Geom1D

::: plycutter.geometry.geom1d.Geom1D
