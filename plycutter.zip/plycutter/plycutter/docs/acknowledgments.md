
Thanks to Timo Jokitalo for pre-release feedback and suggesting the
blog post.

Thanks to Antti Hämäläinen for the courage to test plycutter with a
large acrylic project.

Thanks to Janne Kujala for discussions and the first test model not by
the author.

Thanks to my (tjltjl's) family for ideas, requirements and patience.
