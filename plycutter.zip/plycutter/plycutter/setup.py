#!/usr/bin/env python3

# from KOLANICH/python_project_boilerplate.py

from setuptools import setup

if __name__ == "__main__":
    setup()
